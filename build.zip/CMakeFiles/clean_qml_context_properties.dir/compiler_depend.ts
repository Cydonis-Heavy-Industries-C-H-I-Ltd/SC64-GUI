# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for clean_qml_context_properties.
