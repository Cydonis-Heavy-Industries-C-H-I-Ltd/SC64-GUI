file(REMOVE_RECURSE
  "CMakeFiles/fatfs.dir/third_party/fatfs/ff.c.o"
  "CMakeFiles/fatfs.dir/third_party/fatfs/ff.c.o.d"
  "CMakeFiles/fatfs.dir/third_party/fatfs/ffsystem.c.o"
  "CMakeFiles/fatfs.dir/third_party/fatfs/ffsystem.c.o.d"
  "CMakeFiles/fatfs.dir/third_party/fatfs/ffunicode.c.o"
  "CMakeFiles/fatfs.dir/third_party/fatfs/ffunicode.c.o.d"
  "libfatfs.a"
  "libfatfs.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/fatfs.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
