file(REMOVE_RECURSE
  ".rcc/qmlcache/module_sc64gui.aotstats"
  ".rcc/qmlcache/sc64gui_qml/Main_qml.cpp"
  ".rcc/qmlcache/sc64gui_qml/Main_qml.cpp.aotstats"
  "CMakeFiles/module_sc64gui_aotstats_target"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/module_sc64gui_aotstats_target.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
