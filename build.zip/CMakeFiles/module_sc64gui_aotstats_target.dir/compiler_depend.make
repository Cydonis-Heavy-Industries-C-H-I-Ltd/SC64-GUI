# Empty custom commands generated dependencies file for module_sc64gui_aotstats_target.
# This may be replaced when dependencies are built.
