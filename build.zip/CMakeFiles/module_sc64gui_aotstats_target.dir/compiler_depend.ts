# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for module_sc64gui_aotstats_target.
