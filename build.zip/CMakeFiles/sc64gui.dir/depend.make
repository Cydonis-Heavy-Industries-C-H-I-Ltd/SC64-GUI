# Empty dependencies file for sc64gui.
# This may be replaced when dependencies are built.
