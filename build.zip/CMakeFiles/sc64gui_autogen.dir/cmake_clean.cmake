file(REMOVE_RECURSE
  "CMakeFiles/sc64gui_autogen"
  "sc64gui_autogen/mocs_compilation.cpp"
  "sc64gui_autogen/timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sc64gui_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
