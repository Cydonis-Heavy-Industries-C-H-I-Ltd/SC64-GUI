file(REMOVE_RECURSE
  ".qt/sc64gui_res.txt"
  "CMakeFiles/sc64gui_copy_res"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sc64gui_copy_res.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
