# Empty custom commands generated dependencies file for sc64gui_copy_res.
# This may be replaced when dependencies are built.
