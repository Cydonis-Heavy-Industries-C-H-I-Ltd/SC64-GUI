file(REMOVE_RECURSE
  ".qt/qml_imports/sc64gui_build.cmake"
  "CMakeFiles/sc64gui_qmlimportscan"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sc64gui_qmlimportscan.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
