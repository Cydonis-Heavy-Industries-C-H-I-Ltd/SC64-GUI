# Empty custom commands generated dependencies file for sc64gui_qmlimportscan.
# This may be replaced when dependencies are built.
