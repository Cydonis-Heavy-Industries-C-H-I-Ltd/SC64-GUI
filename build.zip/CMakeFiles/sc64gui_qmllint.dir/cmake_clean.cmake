file(REMOVE_RECURSE
  "CMakeFiles/sc64gui_qmllint"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sc64gui_qmllint.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
