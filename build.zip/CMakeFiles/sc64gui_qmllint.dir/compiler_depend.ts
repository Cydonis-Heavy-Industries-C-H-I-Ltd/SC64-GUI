# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for sc64gui_qmllint.
