# Empty custom commands generated dependencies file for sc64gui_qmllint_json.
# This may be replaced when dependencies are built.
