file(REMOVE_RECURSE
  "CMakeFiles/sc64gui_qmllint_module"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sc64gui_qmllint_module.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
