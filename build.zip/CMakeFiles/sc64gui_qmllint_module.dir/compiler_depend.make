# Empty custom commands generated dependencies file for sc64gui_qmllint_module.
# This may be replaced when dependencies are built.
