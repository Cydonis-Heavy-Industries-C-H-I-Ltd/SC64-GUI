file(REMOVE_RECURSE
  "CMakeFiles/sc64gui_qmltyperegistration"
  "Sc64Gui/sc64gui.qmltypes"
  "meta_types/qt6sc64gui_metatypes.json"
  "meta_types/qt6sc64gui_metatypes.json.gen"
  "meta_types/sc64gui_json_file_list.txt"
  "meta_types/sc64gui_json_file_list.txt.timestamp"
  "sc64gui_autogen/mocs_compilation.cpp"
  "sc64gui_autogen/timestamp"
  "sc64gui_qmltyperegistrations.cpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sc64gui_qmltyperegistration.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
