/****************************************************************************
** Meta object code from reading C++ file 'sc64controller.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.11.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/sc64controller.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sc64controller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.11.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10Sc64WorkerE_t {};
} // unnamed namespace

template <> constexpr inline auto Sc64Worker::qt_create_metaobjectdata<qt_meta_tag_ZN10Sc64WorkerE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "Sc64Worker",
        "devicesFound",
        "",
        "ports",
        "connectionChanged",
        "connected",
        "info",
        "progress",
        "fraction",
        "uploadFinished",
        "ok",
        "message",
        "cardListed",
        "QVariantList",
        "entries",
        "refresh",
        "connectPort",
        "port",
        "disconnectPort",
        "uploadRom",
        "path",
        "listCard",
        "copyToCard",
        "hostPath",
        "cardPath"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'devicesFound'
        QtMocHelpers::SignalData<void(const QStringList &)>(1, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QStringList, 3 },
        }}),
        // Signal 'connectionChanged'
        QtMocHelpers::SignalData<void(bool, const QString &)>(4, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Bool, 5 }, { QMetaType::QString, 6 },
        }}),
        // Signal 'progress'
        QtMocHelpers::SignalData<void(double)>(7, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Double, 8 },
        }}),
        // Signal 'uploadFinished'
        QtMocHelpers::SignalData<void(bool, const QString &)>(9, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Bool, 10 }, { QMetaType::QString, 11 },
        }}),
        // Signal 'cardListed'
        QtMocHelpers::SignalData<void(const QVariantList &, const QString &)>(12, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 13, 14 }, { QMetaType::QString, 11 },
        }}),
        // Slot 'refresh'
        QtMocHelpers::SlotData<void()>(15, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'connectPort'
        QtMocHelpers::SlotData<void(const QString &)>(16, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 17 },
        }}),
        // Slot 'disconnectPort'
        QtMocHelpers::SlotData<void()>(18, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'uploadRom'
        QtMocHelpers::SlotData<void(const QString &)>(19, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 20 },
        }}),
        // Slot 'listCard'
        QtMocHelpers::SlotData<void(const QString &)>(21, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 20 },
        }}),
        // Slot 'copyToCard'
        QtMocHelpers::SlotData<void(const QString &, const QString &)>(22, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 23 }, { QMetaType::QString, 24 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<Sc64Worker, qt_meta_tag_ZN10Sc64WorkerE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject Sc64Worker::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10Sc64WorkerE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10Sc64WorkerE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN10Sc64WorkerE_t>.metaTypes,
    nullptr
} };

void Sc64Worker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<Sc64Worker *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->devicesFound((*reinterpret_cast<std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 1: _t->connectionChanged((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->progress((*reinterpret_cast<std::add_pointer_t<double>>(_a[1]))); break;
        case 3: _t->uploadFinished((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 4: _t->cardListed((*reinterpret_cast<std::add_pointer_t<QVariantList>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 5: _t->refresh(); break;
        case 6: _t->connectPort((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->disconnectPort(); break;
        case 8: _t->uploadRom((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->listCard((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->copyToCard((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (Sc64Worker::*)(const QStringList & )>(_a, &Sc64Worker::devicesFound, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Worker::*)(bool , const QString & )>(_a, &Sc64Worker::connectionChanged, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Worker::*)(double )>(_a, &Sc64Worker::progress, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Worker::*)(bool , const QString & )>(_a, &Sc64Worker::uploadFinished, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Worker::*)(const QVariantList & , const QString & )>(_a, &Sc64Worker::cardListed, 4))
            return;
    }
}

const QMetaObject *Sc64Worker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Sc64Worker::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10Sc64WorkerE_t>.strings))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Sc64Worker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void Sc64Worker::devicesFound(const QStringList & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 0, nullptr, _t1);
}

// SIGNAL 1
void Sc64Worker::connectionChanged(bool _t1, const QString & _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 1, nullptr, _t1, _t2);
}

// SIGNAL 2
void Sc64Worker::progress(double _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 2, nullptr, _t1);
}

// SIGNAL 3
void Sc64Worker::uploadFinished(bool _t1, const QString & _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 3, nullptr, _t1, _t2);
}

// SIGNAL 4
void Sc64Worker::cardListed(const QVariantList & _t1, const QString & _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 4, nullptr, _t1, _t2);
}
namespace {
struct qt_meta_tag_ZN14Sc64ControllerE_t {};
} // unnamed namespace

template <> constexpr inline auto Sc64Controller::qt_create_metaobjectdata<qt_meta_tag_ZN14Sc64ControllerE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "Sc64Controller",
        "devicesChanged",
        "",
        "connectedChanged",
        "busyChanged",
        "progressChanged",
        "statusChanged",
        "cardEntriesChanged",
        "requestRefresh",
        "requestConnect",
        "port",
        "requestDisconnect",
        "requestUpload",
        "path",
        "requestListCard",
        "requestCopyToCard",
        "hostPath",
        "cardPath",
        "refresh",
        "connectPort",
        "disconnectPort",
        "uploadRom",
        "QUrl",
        "fileUrl",
        "refreshCard",
        "copyToCard",
        "devices",
        "connected",
        "busy",
        "progress",
        "status",
        "cardEntries",
        "QVariantList"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'devicesChanged'
        QtMocHelpers::SignalData<void()>(1, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'connectedChanged'
        QtMocHelpers::SignalData<void()>(3, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'busyChanged'
        QtMocHelpers::SignalData<void()>(4, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'progressChanged'
        QtMocHelpers::SignalData<void()>(5, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'statusChanged'
        QtMocHelpers::SignalData<void()>(6, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'cardEntriesChanged'
        QtMocHelpers::SignalData<void()>(7, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'requestRefresh'
        QtMocHelpers::SignalData<void()>(8, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'requestConnect'
        QtMocHelpers::SignalData<void(const QString &)>(9, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 10 },
        }}),
        // Signal 'requestDisconnect'
        QtMocHelpers::SignalData<void()>(11, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'requestUpload'
        QtMocHelpers::SignalData<void(const QString &)>(12, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 13 },
        }}),
        // Signal 'requestListCard'
        QtMocHelpers::SignalData<void(const QString &)>(14, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 13 },
        }}),
        // Signal 'requestCopyToCard'
        QtMocHelpers::SignalData<void(const QString &, const QString &)>(15, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 16 }, { QMetaType::QString, 17 },
        }}),
        // Method 'refresh'
        QtMocHelpers::MethodData<void()>(18, 2, QMC::AccessPublic, QMetaType::Void),
        // Method 'connectPort'
        QtMocHelpers::MethodData<void(const QString &)>(19, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 10 },
        }}),
        // Method 'disconnectPort'
        QtMocHelpers::MethodData<void()>(20, 2, QMC::AccessPublic, QMetaType::Void),
        // Method 'uploadRom'
        QtMocHelpers::MethodData<void(const QUrl &)>(21, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 22, 23 },
        }}),
        // Method 'refreshCard'
        QtMocHelpers::MethodData<void()>(24, 2, QMC::AccessPublic, QMetaType::Void),
        // Method 'copyToCard'
        QtMocHelpers::MethodData<void(const QUrl &)>(25, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 22, 23 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
        // property 'devices'
        QtMocHelpers::PropertyData<QStringList>(26, QMetaType::QStringList, QMC::DefaultPropertyFlags, 0),
        // property 'connected'
        QtMocHelpers::PropertyData<bool>(27, QMetaType::Bool, QMC::DefaultPropertyFlags, 1),
        // property 'busy'
        QtMocHelpers::PropertyData<bool>(28, QMetaType::Bool, QMC::DefaultPropertyFlags, 2),
        // property 'progress'
        QtMocHelpers::PropertyData<double>(29, QMetaType::Double, QMC::DefaultPropertyFlags, 3),
        // property 'status'
        QtMocHelpers::PropertyData<QString>(30, QMetaType::QString, QMC::DefaultPropertyFlags, 4),
        // property 'cardEntries'
        QtMocHelpers::PropertyData<QVariantList>(31, 0x80000000 | 32, QMC::DefaultPropertyFlags | QMC::EnumOrFlag, 5),
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<Sc64Controller, qt_meta_tag_ZN14Sc64ControllerE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject Sc64Controller::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN14Sc64ControllerE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN14Sc64ControllerE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN14Sc64ControllerE_t>.metaTypes,
    nullptr
} };

void Sc64Controller::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<Sc64Controller *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->devicesChanged(); break;
        case 1: _t->connectedChanged(); break;
        case 2: _t->busyChanged(); break;
        case 3: _t->progressChanged(); break;
        case 4: _t->statusChanged(); break;
        case 5: _t->cardEntriesChanged(); break;
        case 6: _t->requestRefresh(); break;
        case 7: _t->requestConnect((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->requestDisconnect(); break;
        case 9: _t->requestUpload((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->requestListCard((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 11: _t->requestCopyToCard((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 12: _t->refresh(); break;
        case 13: _t->connectPort((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->disconnectPort(); break;
        case 15: _t->uploadRom((*reinterpret_cast<std::add_pointer_t<QUrl>>(_a[1]))); break;
        case 16: _t->refreshCard(); break;
        case 17: _t->copyToCard((*reinterpret_cast<std::add_pointer_t<QUrl>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::devicesChanged, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::connectedChanged, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::busyChanged, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::progressChanged, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::statusChanged, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::cardEntriesChanged, 5))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::requestRefresh, 6))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)(const QString & )>(_a, &Sc64Controller::requestConnect, 7))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)()>(_a, &Sc64Controller::requestDisconnect, 8))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)(const QString & )>(_a, &Sc64Controller::requestUpload, 9))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)(const QString & )>(_a, &Sc64Controller::requestListCard, 10))
            return;
        if (QtMocHelpers::indexOfMethod<void (Sc64Controller::*)(const QString & , const QString & )>(_a, &Sc64Controller::requestCopyToCard, 11))
            return;
    }
    if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast<QStringList*>(_v) = _t->devices(); break;
        case 1: *reinterpret_cast<bool*>(_v) = _t->connected(); break;
        case 2: *reinterpret_cast<bool*>(_v) = _t->busy(); break;
        case 3: *reinterpret_cast<double*>(_v) = _t->progress(); break;
        case 4: *reinterpret_cast<QString*>(_v) = _t->status(); break;
        case 5: *reinterpret_cast<QVariantList*>(_v) = _t->cardEntries(); break;
        default: break;
        }
    }
}

const QMetaObject *Sc64Controller::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Sc64Controller::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN14Sc64ControllerE_t>.strings))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Sc64Controller::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 18;
    }
    if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void Sc64Controller::devicesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Sc64Controller::connectedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void Sc64Controller::busyChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Sc64Controller::progressChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void Sc64Controller::statusChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void Sc64Controller::cardEntriesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void Sc64Controller::requestRefresh()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void Sc64Controller::requestConnect(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 7, nullptr, _t1);
}

// SIGNAL 8
void Sc64Controller::requestDisconnect()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void Sc64Controller::requestUpload(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 9, nullptr, _t1);
}

// SIGNAL 10
void Sc64Controller::requestListCard(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 10, nullptr, _t1);
}

// SIGNAL 11
void Sc64Controller::requestCopyToCard(const QString & _t1, const QString & _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 11, nullptr, _t1, _t2);
}
QT_WARNING_POP
